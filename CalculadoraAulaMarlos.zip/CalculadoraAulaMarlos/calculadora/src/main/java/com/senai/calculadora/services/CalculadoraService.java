package com.senai.calculadora.services;

import com.senai.calculadora.dtos.CalculadoraDto;
import com.senai.calculadora.dtos.ResultadoDto;
import org.springframework.stereotype.Service;


@Service
public class CalculadoraService {
    
   
    public ResultadoDto somar(CalculadoraDto calculadoraEntrada){
        ResultadoDto resultado = new ResultadoDto();
        resultado.setNumero1(calculadoraEntrada.getNumero1());  
        resultado.setNumero2(calculadoraEntrada.getNumero2()); 
        resultado.setResultado(calculadoraEntrada.getNumero1() + calculadoraEntrada.getNumero2());
      
        return resultado;
    }
    
    public ResultadoDto subtrair(CalculadoraDto calculadoraEntrada){
        
       
        ResultadoDto resultado = new ResultadoDto();
        resultado.setNumero1(calculadoraEntrada.getNumero1());
        resultado.setNumero2(calculadoraEntrada.getNumero2());
        resultado.setResultado(calculadoraEntrada.getNumero1() - calculadoraEntrada.getNumero2());
        
        return resultado;
    }
    
    public ResultadoDto multiplicar(CalculadoraDto calculadoraEntrada){
        ResultadoDto resultado = new ResultadoDto();
        resultado.setNumero1(calculadoraEntrada.getNumero1());  
        resultado.setNumero2(calculadoraEntrada.getNumero2());      
        resultado.setResultado(calculadoraEntrada.getNumero1() * calculadoraEntrada.getNumero2());
        
        return resultado;
    }    

    public ResultadoDto dividir(CalculadoraDto calculadoraEntrada){
        ResultadoDto resultado = new ResultadoDto();
        resultado.setNumero1(calculadoraEntrada.getNumero1());
        resultado.setNumero2(calculadoraEntrada.getNumero2());
        resultado.setResultado(calculadoraEntrada.getNumero1() / calculadoraEntrada.getNumero2());
        
        return resultado;
    }    
}
