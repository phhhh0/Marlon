package com.senai.calculadora.controllers;

import com.senai.calculadora.dtos.*;
import com.senai.calculadora.services.CalculadoraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController 
@RequestMapping("/calculadora") 
public class CalculadoraController {
    
    @Autowired
    CalculadoraService calcService;
       
    @PostMapping("/soma")
    public ResponseEntity<ResultadoDto> somar(@RequestBody CalculadoraDto calculadoraEntrada){    
        ResultadoDto resultado = calcService.somar(calculadoraEntrada);      
        return ResponseEntity.ok().body(resultado);
    }
    @PostMapping("/subtracao")
    public ResponseEntity<ResultadoDto> subtrair(@RequestBody CalculadoraDto calculadoraEntrada){
       
        ResultadoDto resultado = calcService.subtrair(calculadoraEntrada);
        
       
        return ResponseEntity.ok().body(resultado);
    }

   
    @PostMapping("/multiplicacao")
    public ResponseEntity<ResultadoDto> multiplicar(@RequestBody CalculadoraDto calculadoraEntrada){
        
               
        ResultadoDto resultado = calcService.multiplicar(calculadoraEntrada);
         return ResponseEntity.ok().body(resultado);
    }   
    
     @PostMapping("/divisao")
     public ResponseEntity<ResultadoDto> dividir(@RequestBody CalculadoraDto calculadoraEntrada){
         
          ResultadoDto resultado = calcService.dividir(calculadoraEntrada);
        return ResponseEntity.ok().body(resultado);
    } 
}


